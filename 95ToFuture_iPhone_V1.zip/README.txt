95 → Future — iPhone Version 1
This is a single-file mobile web app.
To use it on iPhone: the HTML must be hosted at a web address. This ZIP contains the app itself; it is not a hosted URL.
Features: daily checkboxes for college, study, gym, physique, skills, English, sports, projects, home and health; Goals; Progress; local browser saving.
